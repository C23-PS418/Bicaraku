package com.projek.bicarakuu.fragment

import android.content.Intent
import android.os.Bundle
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.View
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.projek.bicarakuu.AbjadDetailActivity
import com.projek.bicarakuu.MainActivity
import com.projek.bicarakuu.R
import com.projek.bicarakuu.adapter.AbjadAdapter
import com.projek.bicarakuu.data.DataModel
import com.projek.bicarakuu.databinding.FragmentListAbjadBinding


class ListAbjad : Fragment() {

    private lateinit var binding: FragmentListAbjadBinding
    private lateinit var abjadAdapter: AbjadAdapter
    private var dataList = mutableListOf<DataModel>()


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentListAbjadBinding.inflate(inflater, container, false)
        val view = binding.root

        val recyclerView: RecyclerView = view.findViewById(R.id.recyclerView)

        abjadAdapter = AbjadAdapter(requireContext(), dataList)
        recyclerView.layoutManager = GridLayoutManager(requireContext(), 4)
        recyclerView.adapter = abjadAdapter

        dataList.add(DataModel(R.drawable.icon_a))
        dataList.add(DataModel(R.drawable.icon_b))
        dataList.add(DataModel(R.drawable.icon_c))
        dataList.add(DataModel(R.drawable.icon_d))
        dataList.add(DataModel(R.drawable.icon_e))
        dataList.add(DataModel(R.drawable.icon_f))
        dataList.add(DataModel(R.drawable.icon_g))
        dataList.add(DataModel(R.drawable.icon_h))
        dataList.add(DataModel(R.drawable.icon_i))
        dataList.add(DataModel(R.drawable.icon_j))
        dataList.add(DataModel(R.drawable.icon_k))
        dataList.add(DataModel(R.drawable.icon_l))
        dataList.add(DataModel(R.drawable.icon_m))
        dataList.add(DataModel(R.drawable.icon_n))
        dataList.add(DataModel(R.drawable.icon_o))
        dataList.add(DataModel(R.drawable.icon_p))
        dataList.add(DataModel(R.drawable.icon_q))
        dataList.add(DataModel(R.drawable.icon_r))
        dataList.add(DataModel(R.drawable.icon_s))
        dataList.add(DataModel(R.drawable.icon_t))
        dataList.add(DataModel(R.drawable.icon_u))
        dataList.add(DataModel(R.drawable.icon_v))
        dataList.add(DataModel(R.drawable.icon_w))
        dataList.add(DataModel(R.drawable.icon_x))
        dataList.add(DataModel(R.drawable.icon_y))
        dataList.add(DataModel(R.drawable.icon_z))
        abjadAdapter.notifyDataSetChanged()
        return view
    }
}
